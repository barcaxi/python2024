class Site:
    # add your code here